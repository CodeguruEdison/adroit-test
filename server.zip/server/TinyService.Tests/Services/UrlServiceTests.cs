﻿using TinyService.Service;
using Xunit;

public class UrlServiceTests
{
    private readonly IUrlService _urlService = new UrlService();

    /// <summary>
    /// Tests if a valid short URL is generated for a given long URL.
    /// </summary>
    [Fact]
    public void CreateShortUrl_ShouldReturnValidShortUrl()
    {
        var result = _urlService.CreateShortUrl("https://example.com");

        Assert.NotNull(result);                
        Assert.Equal(8, result.Length);            }

    /// <summary>
    /// Verifies that the correct long URL is retrieved from a short URL.
    /// </summary>
    [Fact]
    public void GetLongUrl_ShouldRetrieveOriginalUrl()
    {
        var shortUrl = _urlService.CreateShortUrl("https://www.adroit-tt.com");
        var longUrl = _urlService.GetLongUrl(shortUrl);

        Assert.Equal("https://www.adroit-tt.com", longUrl); 
    }

    /// <summary>
    /// Confirms that a short URL can be deleted successfully.
    /// </summary>
    [Fact]
    public void DeleteShortUrl_ShouldRemoveEntry()
    {
        var shortUrl = _urlService.CreateShortUrl("https://example.com");
        var isDeleted = _urlService.DeleteShortUrl(shortUrl);

        Assert.True(isDeleted); 
    }

    /// <summary>
    /// Checks if click statistics increment correctly with each URL access.
    /// </summary>
    [Fact]
    public void GetClickStatistics_ShouldTrackClicks()
    {
        var shortUrl = _urlService.CreateShortUrl("https://www.adroit-tt.com");
        _urlService.GetLongUrl(shortUrl);
        _urlService.GetLongUrl(shortUrl);

        var (exists, clickCount) = _urlService.GetClickStatistics(shortUrl);

        Assert.True(exists);
        Assert.Equal(2, clickCount); 
    }

    /// <summary>
    /// Ensures that accessing click statistics for a non-existent URL returns 404.
    /// </summary>
    [Fact]
    public void GetClickStatistics_ShouldReturn404ForNonExistentUrl()
    {
        var (exists, clickCount) = _urlService.GetClickStatistics("invalidCode");

        Assert.False(exists);        // URL should not exist
        Assert.Equal(0, clickCount); // Click count should be zero
    }
}
