﻿namespace TinyService.Models
{
    public class ShortenUrlRequest
    {
        public required string LongUrl { get; set; }
    }
}
