﻿namespace TinyService.Service
{
    public interface IUrlService
    {
        string CreateShortUrl(string longUrl);
        string GetLongUrl(string shortUrl);
        bool DeleteShortUrl(string shortUrl);
        (bool Exists, int ClickCount) GetClickStatistics(string shortUrl);
    }
}
