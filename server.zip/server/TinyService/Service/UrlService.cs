﻿using System.Collections.Concurrent;
using TinyService.Models;
using TinyService.Service;


public class UrlService : IUrlService
{
    private readonly ConcurrentDictionary<string, UrlMapping> _urlStore = new();
    private static readonly Random _random = new();

    /// <summary>
    /// Generates a random 8-character alphanumeric short URL code.
    /// </summary>
    private string GenerateRandomShortUrl()
    {
        const string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        return new string(Enumerable.Repeat(chars, 8)
                                    .Select(s => s[_random.Next(s.Length)])
                                    .ToArray());
    }

    /// <summary>
    /// Creates a new short URL for the provided long URL.
    /// Ensures the generated short URL is unique.
    /// </summary>
    public string CreateShortUrl(string longUrl)
    {
        string shortUrl;
        do
        {
            shortUrl = GenerateRandomShortUrl();
        } while (_urlStore.ContainsKey(shortUrl)); // Ensure uniqueness

        _urlStore[shortUrl] = new UrlMapping { ShortUrl = shortUrl, LongUrl = longUrl };
        return shortUrl;
    }

    /// <summary>
    /// Retrieves the original long URL for a given short URL.
    /// Increments the click count for tracking purposes.
    /// </summary>
    public string GetLongUrl(string shortUrl)
    {
        if (_urlStore.TryGetValue(shortUrl, out var mapping))
        {
            mapping.ClickCount++; // Increment click count
            return mapping.LongUrl;
        }
        return null; // Return null if the short URL doesn't exist
    }

    /// <summary>
    /// Deletes an existing short URL from the system.
    /// </summary>
    public bool DeleteShortUrl(string shortUrl) => _urlStore.TryRemove(shortUrl, out _);

    /// <summary>
    /// Retrieves click statistics (number of times the short URL has been accessed).
    /// Returns a tuple indicating if the URL exists and its click count.
    /// </summary>
    public (bool Exists, int ClickCount) GetClickStatistics(string shortUrl)
    {
        if (_urlStore.TryGetValue(shortUrl, out var mapping))
        {
            return (true, mapping.ClickCount);
        }
        return (false, 0); // Return 0 clicks if the URL doesn't exist
    }
}
