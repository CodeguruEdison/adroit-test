﻿using Microsoft.AspNetCore.Mvc;
using TinyService.Models;
using TinyService.Service;

[ApiController]
[Route("api")]
public class UrlController : ControllerBase
{
    private readonly IUrlService _urlService;
    public UrlController(IUrlService urlService) => _urlService = urlService;

    /// <summary>
    /// Endpoint to create a short URL for the provided long URL.
    /// </summary>
    [HttpPost("shorten")]
    public IActionResult Shorten([FromBody] ShortenUrlRequest request)
    {
        var shortUrl = _urlService.CreateShortUrl(request.LongUrl);
        return Ok(new { ShortUrl = shortUrl });
    }

    /// <summary>
    /// Expands a short URL code to retrieve the original long URL.
    /// Returns 404 if the short URL is not found.
    /// </summary>
    [HttpGet("expand/{shortUrl}")]
    public IActionResult Expand(string shortUrl)
    {
        var longUrl = _urlService.GetLongUrl(shortUrl);
        return longUrl != null ? Ok(new { LongUrl = longUrl }) : NotFound();
    }
    /// <summary>
    /// Deletes a short URL from the system.
    /// Returns 404 if the short URL does not exist.
    /// </summary>
    [HttpDelete("shorten/{shortUrl}")]
    public IActionResult Delete(string shortUrl) =>
        _urlService.DeleteShortUrl(shortUrl) ? Ok() : NotFound();

    /// <summary>
    /// Retrieves the number of times the short URL has been clicked.
    /// Returns 404 if the short URL is not found.
    /// </summary>
    [HttpGet("stats/{shortUrl}")]
    public IActionResult Stats(string shortUrl)
    {
        var (exists, clickCount) = _urlService.GetClickStatistics(shortUrl);
        return exists ? Ok(new { ClickCount = clickCount }) : NotFound();
    }
}
