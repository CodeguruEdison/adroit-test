import React, { useState } from 'react';
import { useExpandUrl, useDeleteUrl, useGetUrlStats } from '../hooks/useUrlHooks';

import { UrlListProps } from '@/types/UrlShortner.type';
import UrlShortener from './UrlShortener';
const UrlList: React.FC<UrlListProps> = ({ urls, onDelete, onAdd }) => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [activeStats, setActiveStats] = useState<{ [key: string]: number }>({});
  const expandMutation = useExpandUrl();
  const statsMutation = useGetUrlStats({
    onSuccess: (data, shortUrl) => {
      setActiveStats((prev) => ({ ...prev, [shortUrl]: data.clickCount }));
    },
  });
  const deleteMutation = useDeleteUrl(onDelete);

  return (
    <div className="space-y-4 relative">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">URL Shortener List</h2>
        <button
          className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded"
          onClick={() => setIsDrawerOpen(true)}
        >
          Add New URL
        </button>
      </div>

      {isDrawerOpen && (
        <div className="fixed top-0 right-0 w-80 h-full bg-white shadow-lg p-4 z-50 transition-transform transform translate-x-0">
          <button
            className="text-red-500 mb-4 text-right w-full"
            onClick={() => setIsDrawerOpen(false)}
          >
            Close
          </button>
          <UrlShortener onShorten={onAdd} onClose={() => setIsDrawerOpen(false)} />
        </div>
      )}

      {urls.map((url) => (
        <div key={url.shortUrl} className="p-4 bg-gray-50 rounded-lg shadow-md flex flex-col md:flex-row justify-between items-start gap-4">
          <div className="flex-1">
            <p className="text-gray-800 font-semibold">Short URL:</p>
            <a href={url.shortUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline break-words">
              {url.shortUrl}
            </a>
            <p className="text-gray-800 font-semibold mt-2">Long URL:</p>
            <p className="text-gray-600 break-words">{url.longUrl}</p>
            <p className="text-gray-500 text-sm mt-1">Created At: {new Date(url.createdAt).toLocaleString()}</p>

            {activeStats[url.shortUrl] !== undefined && (
              <p className="text-green-600 font-semibold mt-2">Clicks: {activeStats[url.shortUrl]}</p>
            )}
          </div>

          <div className="flex space-x-2 md:ml-4">
            <button
              className="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded"
              onClick={() => expandMutation.mutate(url.shortUrl)}
            >
              Expand
            </button>
            <button
              className="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded"
              onClick={() => statsMutation.mutate(url.shortUrl)}
            >
              Stats
            </button>
            <button
              className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded"
              onClick={() => deleteMutation.mutate(url.shortUrl)}
            >
              Delete
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default UrlList;
