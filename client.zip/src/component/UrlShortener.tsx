import React, { useState } from 'react';
import { useShortenUrl } from '../hooks/useUrlHooks';
import { UrlShortenerProps } from '@/types/UrlShortner.type';
const UrlShortener: React.FC<UrlShortenerProps> = ({ onShorten, onClose }) => {
    const [longUrl, setLongUrl] = useState('');
    const [customAlias, setCustomAlias] = useState('');

    const mutation = useShortenUrl((data) => {
        onShorten({ ...data, createdAt: new Date().toISOString() });
        alert('URL shortened successfully!');
        if (onClose) onClose();
    });

    return (
        <div className="space-y-4 bg-white p-4 rounded-lg shadow-md max-w-lg mx-auto">
            <input
                className="w-full p-2 border rounded"
                placeholder="Enter Long URL"
                value={longUrl}
                onChange={(e) => setLongUrl(e.target.value)}
            />
            <button
                className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 rounded"
                onClick={() => mutation.mutate({ longUrl, customAlias })}
            >
                Shorten URL
            </button>
        </div>
    );
};

export default UrlShortener;