// src/services/apiService.ts
import axios from 'axios';

// Create an Axios instance with the base URL
const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
});

export const shortenUrl = (longUrl: string, customAlias?: string) =>
  apiClient.post('/api/shorten', { longUrl, shortUrl: customAlias }).then(res => res.data);

export const expandUrl = (shortUrl: string) => {
  const code = shortUrl.split('/').pop();
  return apiClient.get(`/api/expand/${code}`).then(res => res.data);
};

export const deleteUrl = (shortUrl: string) => {
  const code = shortUrl.split('/').pop();
  return apiClient.delete(`/api/shorten/${code}`).then(res => res.data);
};

export const getUrlStats = (shortUrl: string) => {
  const code = shortUrl.split('/').pop();
  return apiClient.get(`/api/stats/${code}`).then(res => res.data);
};
