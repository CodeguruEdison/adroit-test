
import React, { useState } from 'react';


import UrlList from './component/UrlList';
import { UrlItem } from './types/UrlShortner.type';
import './App.css';

const App: React.FC = () => {
  const [urls, setUrls] = useState<UrlItem[]>([]);

  const handleAddUrl = (url: UrlItem) => {
    setUrls((prev) => [...prev, url]);
  };

  const handleDeleteUrl = (shortUrl: string) => {
    setUrls((prev) => prev.filter((url) => url.shortUrl !== shortUrl));
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4 md:p-8">
      <h1 className="text-3xl font-bold text-center text-blue-700 mb-6">TinyURL POC</h1>
      {/* <UrlShortener onShorten={handleAddUrl} /> */}
      <div className="mt-12">
        <UrlList urls={urls} onDelete={handleDeleteUrl} onAdd={handleAddUrl} />
      </div>
    </div>
  );
};
export default App;