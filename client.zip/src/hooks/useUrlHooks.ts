import { useMutation, useQueryClient } from 'react-query';
import { shortenUrl, expandUrl, deleteUrl, getUrlStats } from '../services/apiService';

export const useShortenUrl = (onSuccess: (data: any) => void) => {
  const queryClient = useQueryClient();
  return useMutation((params: { longUrl: string; customAlias?: string }) => shortenUrl(params.longUrl, params.customAlias), {
    onSuccess: (data) => {
      onSuccess(data);
      queryClient.invalidateQueries('urls');
    },
  });
};

export const useExpandUrl = () => useMutation(expandUrl);

export const useDeleteUrl = (onSuccess: (shortUrl: string) => void) => {
  const queryClient = useQueryClient();
  return useMutation(deleteUrl, {
    onSuccess: (_, shortUrl) => {
      onSuccess(shortUrl);
      queryClient.invalidateQueries('urls');
    },
  });
};
export const useGetUrlStats = (p0: { onSuccess: (data: any, shortUrl: any) => void; }) => useMutation(getUrlStats);