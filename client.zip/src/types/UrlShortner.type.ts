export interface UrlItem {
    shortUrl: string;
    longUrl: string;
    createdAt?: string;
}

export interface UrlListProps {
    urls: UrlItem[];
    onDelete: (shortUrl: string) => void;
    onAdd: (url: UrlItem) => void;
}

export interface UrlShortenerProps {
    onShorten: (url: { shortUrl: string, longUrl: string }) => void;
    onClose?: () => void;
}